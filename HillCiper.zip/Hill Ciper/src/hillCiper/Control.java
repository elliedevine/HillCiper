package hillCiper;

public class Control {

}
